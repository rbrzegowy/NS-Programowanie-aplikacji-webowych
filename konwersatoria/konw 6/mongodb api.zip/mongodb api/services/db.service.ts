import { WithoutId } from './../models/without-id.model'
import * as mongoDb from 'mongodb'
// import {Db, } from 'mongodb'
import config from '../config.json'
import { assertMongoId } from '../helpers/assert-mongo-id.guard'
import { createMongoId } from '../helpers/create-mongo-id'
import { WithId } from '../models/with-id.model'
import { Filter } from 'mongodb'
import { Note } from '../models/note.models'

class DbService {
  private db!: mongoDb.Db
  constructor() {
    this.connect()
  }
  private async connect() {
    const client = new mongoDb.MongoClient(config.mongodb_uri)
    await client.connect()
    this.db = client.db(config.db_name)
  }
  create(data: mongoDb.Document, collection: string) {
    return this.db.collection(collection).insertOne(data)
      .then(data => data.acknowledged ? data.insertedId.toString() : null)
  }
  delete(id: string, collection: string) {
    const query = {
      "_id": createMongoId(id)
    }
    return this.db.collection(collection)
      .deleteOne(query)
      .then(result =>
        !!result.deletedCount
      )
  }
  findOne<DataType extends mongoDb.Document = mongoDb.Document>(id: string, collection: string) {
    const query: WithId<mongoDb.Document> = {
      "_id": createMongoId(id)
    }
    return this.db
      .collection(collection)
      .findOne<DataType>(query)
  }
  replace(id: string, data: WithoutId<mongoDb.Document>, collection: string) {
    const query = {
      "_id": createMongoId(id)
    }
    return this.db.collection(collection)
      .replaceOne(query, data)
      .then(result =>
        !!result.modifiedCount
      )
  }
  patch(id: string, data: mongoDb.Document, collection: string) {
    const query = {
      "_id": createMongoId(id)
    }
    return this.db.collection(collection)
      .updateOne(query, { $set: { ...data } })
      .then(result =>
        !!result.modifiedCount
      )
  }

  find<DataType extends Record<string, any> = Record<string, any>>(query = {}, collection: string) {
    // const query2 = {
    //   title: '7',
    // $or: [
    //   visited: { $gt: 3, $lt: 10 },
    //   content: { $exists: true },
    //  ]
    // }

    // return this.db.collection(collection).find(query).sort({title: 1, content: -1})
    return this.db
      .collection(collection)
      .find<DataType>(query)
      .toArray()
  }

  // inne przykłady zapytań dla Note

  // projekcja - zwróć tylko tytuł i datę utworzenia
  findWithProjection(
    collection: string
  ) {
    return this.db
      .collection<Note>(collection)
      .find({}, { projection: { title: 1, dateCreated: 1 } })
      .toArray()
  }
  // wykluczanie pól
  findNoteWithoutContent(
    collection: string
  ) {
    return this.db
      .collection<Note>(collection)
      .find({}, { projection: { content: 0 } })
  }

  // filtrowanie - $gt, $lt, $gte, $lte, $ne, $in, $nin, $exists
  findWithFilters(
    collection: string
  ) {
    const query = {
      private: false,
      views: { $gte: 10 },
      tags: { $in: ["work", "important"] },
      dateCreated: { $gte: new Date("2024-01-01") }
    }

    return this.db
      .collection<Note>(collection)
      .find(query)
      .toArray()
  }

  // sortowanie
  findSorted(
    collection: string
  ) {
    return this.db
      .collection<Note>(collection)
      .find({})
      .sort({
        pinned: -1,
        views: -1,
        dateCreated: -1
      })
      .toArray()
  }

  // paginacja
  findPaginated(
    collection: string,
    page = 1,
    limit = 10
  ) {
    return this.db
      .collection<Note>(collection)
      .find({})
      .skip((page - 1) * limit)
      .limit(limit)
      .sort({ dateCreated: -1 })
      .toArray()
  }

  // grupowanie i agregacja - ile mamy dokumentów z danym tagiem
  groupByTags(collection: string) {
    return this.db.collection(collection).aggregate([
      { $unwind: "$tags" },
      {
        $group: {
          _id: "$tags",
          count: { $sum: 1 }
        }
      },
      { $sort: { count: -1 } }
    ]).toArray()
  }

  // obliczenia
  getStats(collection: string) {
    return this.db.collection(collection).aggregate([
      {
        $group: {
          _id: null,
          avgViews: { $avg: "$views" },
          maxViews: { $max: "$views" },
          totalViews: { $sum: "$views" },
          count: { $sum: 1 }
        }
      }
    ]).toArray()
  }

  // łączenie (ale why o why my captain?)
  // projekcja wybranych pól
  findWithJoin(
    collection: string
  ) {
    return this.db
      .collection<Note>(collection)
      .aggregate([
        {
          $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "user"
          }
        },
        {
          $unwind: "$user" // zamienia array -> obiekt
        }
      ])
      .toArray()
  }
}
export const dbService = new DbService()