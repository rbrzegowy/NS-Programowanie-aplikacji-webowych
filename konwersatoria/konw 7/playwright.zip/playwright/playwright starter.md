# Playwright Starter

## 1) Szybki start

1. Zainstaluj playwright:

```bash
npm init playwright
```

2. Uruchom wszystkie testy:

```bash
npx playwright test
```

3. Uruchom pojedynczy plik:

```bash
npx playwright test tests/ideis.spec.ts
```

4. Uruchom testy w widocznym oknie przeglądarki:

```bash
npx playwright test --headed
```

5. Uruchom testy tylko w wybranym środowisku:

```bash
npx playwright test --project=chromium
```

6. Otwórz raport HTML po teście:

```bash
npx playwright show-report
```

## 2) Hello world

```ts
import { test, expect } from '@playwright/test'

test('strona główna Kraków wyświetla sekcję studiów', async ({ page }) => {
	await page.goto('https://ideis.pl/krakow')

	// Krótka walidacja: poprawny adres i widoczny główny nagłówek sekcji.
	await expect(page).toHaveURL(/\/krakow\/?$/)
	await expect(page.getByRole('heading', { name: 'Studia i szkolenia' })).toBeVisible()
})
```

### Timeouty testów
#### Domyślne timeouty
- Timeout całego testu: 30 s.
- Timeout asercji expect(...): 5 s.
- Akcje na locatorach (np. click, fill, selectOption) czekają automatycznie. Bez ustawionego actionTimeout zwykle ogranicza je timeout testu.

#### Zmiana timeout

```ts
import { test, expect } from '@playwright/test'

test('przykład z timeoutami', async ({ page }) => {
	// Zmiana timeoutu tylko dla tego testu.
	test.setTimeout(60_000)

	await page.goto('https://ideis.pl/krakow')

	// Zmiana timeoutu tylko dla jednej asercji.
	await expect(page.getByRole('heading', { name: 'Studia i szkolenia' })).toBeVisible({ timeout: 10_000 })
})
```

Globalnie (w playwright.config.ts):

```ts
import { defineConfig } from '@playwright/test'

export default defineConfig({
	timeout: 60_000,
	expect: {
		timeout: 10_000,
	},
	use: {
		actionTimeout: 15_000,
		navigationTimeout: 30_000,
	},
})
```

## 3) Standardowe konstrukcje w budowie testów

### 3.1 Grupowanie testów

- test.describe('nazwa grupy', () => { ... })
- Służy do logicznego podziału testów (np. logowanie, wyszukiwarka, koszyk).

### 3.2 Hooki

- test.beforeAll(...): uruchamiany raz przed testami w workerze.
- test.afterAll(...): uruchamiany raz po testach w workerze.
- test.beforeEach(...): uruchamiany przed każdym testem.
- test.afterEach(...): uruchamiany po każdym teście.

Najczęściej beforeEach używa się do wejścia na stronę startową i przygotowania stanu.
W praktyce najczęściej używa się pary: test.beforeEach i test.afterEach.

### 3.3 Ciało testu

- test('nazwa testu', async ({ page }) => { ... })
- page to wbudowany obiekt (fixture) z izolowanym kontekstem przeglądarki.
- Każdy test działa w izolacji (oddzielny BrowserContext).

### 3.4 Kroki testu

- test.step('opis kroku', async () => { ... })
- Ułatwia czytelność i debugowanie raportów.

### 3.5 Lokatory i akcje

- Preferuj lokatory semantyczne: getByRole, getByLabel, getByText. Działamy jak człowiek.
- Używaj locator(...) gdy potrzebujesz precyzyjnego selektora technicznego (a selektory/atrybuty semantyczne nie dają takiej możliwości)

Popularne akcje:
- click()
- hover()
- focus()
- fill()/type(slow)
- press(one)
- check()/uncheck()
- selectOption()

### 3.7 Asercje

- await expect(locator).toBeVisible()
- await expect(page).toHaveURL(...)
- await expect(locator).toHaveText(...)

Asercje Playwright automatycznie czekają na spełnienie warunku, co ogranicza flaky testy.

### 3.8 Dodatkowa konfiguracja testów:

- test.describe.configure(...), test.use(...), pętle po danych.
- Przydatne do uruchamiania jednego scenariusza dla wielu wejść
- Przydaten dla zmiany trybu działania konkretnego testu (np. set testowy po kolei lub równolegle)

### 3.9 Oznaczenia i kontrola testu

- test.only(...): uruchamia tylko wskazany test.
- test.skip(...): pomija test.
- test.fixme(...): oznacza test do naprawy.
- test.slow(...): zwiększa budżet czasu dla wolnego testu.

## 4) Szablon kompletnego pliku testowego

```ts
import { test, expect } from '@playwright/test'

test.describe('Strona ideis.pl/krakow', () => {
	test.beforeEach(async ({ page }) => {
		await page.goto('https://ideis.pl/krakow')
	})

	test.afterEach(async ({ page }) => {
		await page.screenshot({ path: `./screenshots/${test.info().title}.png`, fullPage: true })
	})

	test('przejście do kierunków studiów I stopnia', async ({ page }) => {
		await test.step('Sprawdzenie głównej sekcji', async () => {
			await expect(page.getByRole('heading', { name: 'Studia i szkolenia' })).toBeVisible()
		})

		await test.step('Przejście do listy Studiów I stopnia', async () => {
			await page.getByRole('link', { name: 'Studia I stopnia' }).first().click()
		})

		await test.step('Asercje strony docelowej', async () => {
			await expect(page).toHaveURL(/studia-i-szkolenia\/studia-i-stopnia/)
			await expect(page.getByRole('heading', { name: /Studia I stopnia/i })).toBeVisible()
		})
	})
})
```

## 4.1 Dodatkowy przykład: sekcja kontakt

```ts
import { test, expect } from '@playwright/test'

test('przejście do strony kontakt', async ({ page }) => {
	await page.goto('https://ideis.pl/krakow')
	await page.getByRole('link', { name: 'Kontakt' }).first().click()
	await expect(page).toHaveURL(/\/krakow\/kontakt/)
	await expect(page.getByRole('heading', { name: /Kontakt/i })).toBeVisible()
})
```

## 5) Dobre praktyki na start

1. Najpierw lokatory semantyczne (getByRole), potem CSS/XPath.
2. Unikaj twardych waitów typu waitForTimeout.
3. Każdy test powinien mieć minimum 1-2 sensowne asercje.
4. Nie mieszaj kilku niezależnych scenariuszy w jednym teście.
5. Zachowuj jeden cel biznesowy na test.

#### AssertObject
Dla każdej nieoczywistej asercji stosuj wzorzec AsserObject  
Wzorzec AssertObject:
- ukrywa implementacje techniczną za opisem biznesowym
- ma zrozumiały język nie tylko dla programisty
- pokazuje jaka jest wartość biznesowa (nie zawsze jest!) 
  
Na przykład - zamiast 
```ts
// zamiast
assert.isEqual(cartLenght,2) 
// można zrobić obiekt z metodą 
cartAssertions.hasXItems(2)

// zamiast 
assert.equal(order.payment != null && order.delivery != null && order.cart.value>0) 
// można zrobić 
cartAssertions.readyToOrder(cart)
```
W nowszych podejściach często stosujemy funkcje zamiast obiektów.

#### PageObjects
PageObject to wzorzec używany w testach UI/E2E, w którym:
- każda strona lub komponent aplikacji jest reprezentowany przez klasę/zestaw funkcji,
- selektory i akcje na UI są schowane wewnątrz tej klasy,
- test używa metod biznesowych zamiast klikania locatorów bezpośrednio.
- można zawrzeć asercje (wygodniejsze niż osobne AssertObject w małych produktach)
  

Przykład:
```ts
import { test, expect, type Page } from '@playwright/test'

// PRZED: test zna szczegóły UI (locatory). Zmiana locatora = zmiana wszystkich testów na nim bazujących
test('koszyk - bez PageObject', async ({ page }) => {
	await page.goto('https://jakis.sklep/')
	await page.getByRole('button', { name: 'Dodaj do koszyka' }).first().click()
	await page.getByRole('link', { name: 'Koszyk' }).click()
	await expect(page.getByTestId('cart-count')).toHaveText('1')
})

// PO: szczegóły UI są schowane w klasie PageObject.
class ShopPage {
	constructor(private page: Page) {}

	async open() {
		await this.page.goto('https://jakis.sklep/')
	}

	async addFirstProductToCart() {
		await this.page.getByRole('button', { name: 'Dodaj do koszyka' }).first().click()
	}

	async openCart() {
		await this.page.getByRole('link', { name: 'Koszyk' }).click()
	}

	async expectCartCount(count: number) {
		await expect(this.page.getByTestId('cart-count')).toHaveText(String(count))
	}
}

test('koszyk - z PageObject', async ({ page }) => {
	const shop = new ShopPage(page)

	await shop.open()
	await shop.addFirstProductToCart()
	await shop.openCart()
	await shop.expectCartCount(1)
})

```

## 6) Co dalej

- Running tests: https://playwright.dev/docs/running-tests
- Locators: https://playwright.dev/docs/locators
- Assertions: https://playwright.dev/docs/test-assertions
- Hooks i API test runnera: https://playwright.dev/docs/api/class-test
- Trace Viewer: https://playwright.dev/docs/trace-viewer-intro
