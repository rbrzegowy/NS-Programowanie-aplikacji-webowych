import { test, expect } from '@playwright/test'

test.describe('IDEIS Starter - Krakow', () => {
  test.beforeEach(async ({ page }) => {
    // Ustawiamy viewport na typowy rozmiar desktopa, aby uniknąć problemów z responsywnością.
    await page.setViewportSize({ width: 1280, height: 800 })
    await page.goto('https://ideis.pl/krakow')
  })
  test('strona glowna Krakow jest dostepna', async ({ page }) => {
    // Krotka walidacja: poprawny adres i widoczny glowny naglowek.
    await expect(page).toHaveURL(/\/krakow\/?$/)
    await expect(page.getByRole('heading', { name: 'IDEIS Kraków' })).toBeVisible()
  })

  test('strona glowna Krakow wyswietla sekcje studiow', async ({ page }) => {
    // Krotka walidacja: poprawny adres i widoczny glowny naglowek sekcji.
    await expect(page).toHaveURL(/\/krakow\/?$/)
    await expect(page.getByRole('heading', { name: 'Studia i szkolenia' })).toBeVisible()
  })
  test.afterEach(async ({ page }) => {
    // Zamykamy stronę po każdym teście, aby upewnić się, że nie ma problemów z pamięcią.
    await page.close()
  })
})