import { test, expect } from '@playwright/test'

test('test', async ({ page }) => {
  const expectedPrice = '729 zł'
  await page.goto('https://www.ideis.pl/krakow/')
  await page.getByRole('searchbox', { name: 'Szukaj' }).click()
  await page.getByRole('searchbox', { name: 'Szukaj' }).fill('informatyka')
  await page.getByRole('searchbox', { name: 'Szukaj' }).click()
  await page.getByRole('searchbox', { name: 'Szukaj' }).press('Enter')


  await page.locator('#ui-id-2').click()
  const pricetag = await page.getByRole('strong').filter({ hasText: '729' })
  expect(pricetag).toBeVisible()
  expect(pricetag).toHaveText(expectedPrice)
})