# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pepper.spec.ts >> iszukajka
- Location: tests/pepper.spec.ts:3:5

# Error details

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "https://www.pepper.pl/", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test('iszukajka', async ({ page }) => {
> 4  |   await page.goto('https://www.pepper.pl/')
     |              ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
  5  | 
  6  |   await page.getByRole('button', { name: 'Akceptuj wszystkie' }).click()
  7  | 
  8  |   await page.getByRole('textbox', { name: 'Szukaj...' }).click()
  9  |   await page.getByRole('textbox', { name: 'Szukaj...' }).fill('iphone')
  10 |   await page.getByRole('textbox', { name: 'Szukaj...' }).press('Enter')
  11 | 
  12 |   await page.getByRole('listitem').filter({ hasText: 'Ukryj zakończone' }).locator('span').nth(1).click()
  13 | 
  14 |   await page.locator('span').filter({ hasText: 'Największa trafność' }).getByRole('combobox').selectOption('lowest_price')
  15 | 
  16 |   // od tego miejsca można zacząć test;)
  17 |   await page.goto('https://www.pepper.pl/search?q=iphone&hide_expired=true&sortBy=lowest_price')
  18 |   await page.screenshot({ path: './screenshots/screenshot.png', fullPage: true })
  19 | })
```